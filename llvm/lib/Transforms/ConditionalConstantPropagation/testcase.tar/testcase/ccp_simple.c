int main () {
	int i, j, k;

	j = 2;
	k = 3;
	i = j - 3;

	if ( i > 3 )
		i += 2;
	else 
		j ++;

	return k;
}
