//===- ConditionalConstantPropagation.cpp - Example code from "Writing an LLVM Pass" ---------------===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//
//
// This file implements two versions of the LLVM "ConditionalConstantPropagation World" pass described
// in docs/WritingAnLLVMPass.html
//
//===----------------------------------------------------------------------===//

#include "llvm/ADT/Statistic.h"
#include "llvm/ADT/StringMap.h"
#include "llvm/IR/Function.h"
#include "llvm/Pass.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Support/FormattedStream.h"
#include "llvm/ADT/DepthFirstIterator.h"
#include "llvm/ADT/GraphTraits.h"
#include "llvm/Support/CFG.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"
#include <map>
#include <set>

using namespace llvm;


namespace {
  // ConditionalConstantPropagation - The first implementation, without getAnalysisUsage.
  struct ConditionalConstantPropagation : public FunctionPass {
    static char ID; // Pass identification, replacement for typeid
    ConditionalConstantPropagation() : FunctionPass(ID) {}

	void ExampleCode ( raw_ostream& O, Function & F);

	void RunCCP( Function & F);

    virtual bool runOnFunction(Function &F) {
      errs() << "ConditionalConstantPropagation: ";
      errs().write_escaped(F.getName()) << '\n';
	  ExampleCode(errs(), F);
	  RunCCP(F);
      return false;
    }

  };
}

char ConditionalConstantPropagation::ID = 0;
static RegisterPass<ConditionalConstantPropagation> X("conditional-constant-propagation", "Data-flow analysis: liveness analysis pass");

void ConditionalConstantPropagation::ExampleCode(raw_ostream& O, Function& F) {

	std::set<StringRef> var_set;
	var_set.clear();
	BasicBlock* bb_entry 	= NULL;
	BasicBlock* bb_if_then 	= NULL;
	BasicBlock* bb_if_else 	= NULL;
	BasicBlock* bb_if_end  	= NULL;

	// TA: The following code shows how you iterate over variables 
	// defined in this function
	O << "All Variables Defined in Function " << F.getName() <<   "\n";
	for (Function::iterator FI = F.begin(), FE = F.end(); FI != FE; ++FI) {
		BasicBlock* BB = dyn_cast<BasicBlock>(&*FI);
		for (BasicBlock::iterator BI = BB->begin(), BE = BB->end();
			BI != BE; ++BI) {
			if ( BI->hasName() ) {
				StringRef var_name = BI->getValueName()->first();
				O << "VARIABLE:\t" << var_name << "\tdefined in ";
				BI->print(O);
				O << "\n";
			}

		}
		if ( !bb_entry )
			bb_entry = BB;
		else if ( !bb_if_then )
			bb_if_then = BB;
		else if ( !bb_if_else )
			bb_if_else = BB;
		else if ( !bb_if_end )
			bb_if_end = BB;
	}

	//TA: The following code examines the last instruction of 
	// each basic block, and print if the last instruction is 
	// condtional or unconditional branch
	for (Function::iterator FI = F.begin(), FE = F.end(); FI != FE; ++FI) {
		BasicBlock* BB = dyn_cast<BasicBlock>(&*FI);
		O << "----------------------------------------------------\n";
		O << "BB: " << BB ->getName() << '\n';
		TerminatorInst *TI = BB->getTerminator();
		O << "\tTerminatorInst: " << *TI << '\n';
		if (BranchInst *BI = dyn_cast<BranchInst>(TI)) {
			if (BI->isUnconditional())
				O << "\tInstruction is uncondtional\n";
			else  {
				O << "\tInstruction is conditional\n";
				Value * condition = BI->getCondition();
				O << "\t\tcondtion is " << *condition << "\n";
			}
		}
	}
	
	// TA: the following code shows how to perform the symbolic execution 
	for (Function::iterator FI = F.begin(), FE = F.end(); FI != FE; ++FI) {
		BasicBlock* BB = dyn_cast<BasicBlock>(&*FI);
		for (BasicBlock::iterator BI = BB->begin(), BE = BB->end();
			BI != BE; ++BI) {
			if ( BI->getOpcode() == Instruction::Sub)  {
				O << "Sub Instr: " << *BI << "\n";
				unsigned operand_size = BI->getNumOperands();
				assert ( operand_size == 2 );
				if ( dyn_cast<ConstantInt>(&*BI->getOperand(0)) && dyn_cast<ConstantInt>(&*BI->getOperand(1)) ) {
					Constant * expr_result = ConstantExpr::getSub(dyn_cast<Constant>(&*BI->getOperand(0)), dyn_cast<Constant>(&*BI->getOperand(1)) );
					if ( ConstantInt * int_result = dyn_cast<ConstantInt>(&*expr_result) ) {
						O << "Both operands are constant, result is: " << int_result->getValue() << "\n"; 
						// replace instruction using 
						// ReplaceInstWithValue
						//BasicBlock::iterator ii(instToReplace);
						ReplaceInstWithValue(BI->getParent()->getInstList(), BI, int_result );
					}
				}
			}

		}
	}

	// TA: the following code shows how to change the IF condition
	// when it always executes false path
	TerminatorInst *TI; 
	TI = bb_entry->getTerminator();
	O << "TerminatorInst in Entry Block: " << *TI;
	if (BranchInst *BI = dyn_cast<BranchInst>(TI)) {
		if (BI->isUnconditional())
			O << " (Uncondtional)\n";
		else if (BI->isConditional())
			O << " (Condtional)\n";
	}
	BasicBlock::iterator BI = bb_entry->begin();
	if ( ICmpInst * icmpinst = dyn_cast<ICmpInst>(&*BI) ) {
		O << " ICmpInst " << *icmpinst << "\n";
		if ( icmpinst->isSigned() ) {
			if (icmpinst->getSignedPredicate () == CmpInst::ICMP_SGT ) {
				O << icmpinst->getSignedPredicate ()  << ": int signed greater than\n";
				Value * left_hand_side  = icmpinst->getOperand(0);
				Value * right_hand_side = icmpinst->getOperand(1);
				if ( dyn_cast<ConstantInt> (&*left_hand_side) && dyn_cast<ConstantInt>(&*right_hand_side)) {
					ConstantInt * left_const  = dyn_cast<ConstantInt> (&*left_hand_side);
					ConstantInt * right_const = dyn_cast<ConstantInt> (&*right_hand_side);   
					O << "LHS is constant: " << *left_const << ", value: " << left_const->getValue() << "\n";
					O << "RHS is constant: " << *right_const<< ", value: " << right_const->getValue() << "\n";
					int64_t left_value = left_const->getValue().getSExtValue();
					int64_t right_value = right_const->getValue().getSExtValue();
					if ( left_value > right_value ) {
						O << "this if statement will always be true\n";
					} else {
						O << "this if statement will always be false\n";
						// if this is the case, we need to replace the terminator instruction (condtional branch ) with new one
						BasicBlock::iterator ii(TI);
						BranchInst * new_branch = BranchInst::Create(TI->getSuccessor(0),  
																	TI->getSuccessor(1),
																	cast<Value>(&*ConstantInt::getFalse(TI->getContext())));
																	//TI->getParent());

						ReplaceInstWithInst(TI->getParent()->getInstList(), ii, cast<Instruction>(&*new_branch));
					}
				}
			}
		}
	}
}


void ConditionalConstantPropagation::RunCCP( Function & F) {

}
